"""Constants for the AC Heating integration."""

DOMAIN = "ac_heating"
